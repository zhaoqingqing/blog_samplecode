﻿using UnityEngine;
using System.Collections;

public class test_script : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        new TestForm().Show();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
