﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Drawing.Drawing2D
{
    public enum DashStyle
    {
        Solid = 0,
        Dash = 1,
        Dot = 2,
        DashDot = 3,
        DashDotDot = 4,
        Custom = 5,
    }
}
