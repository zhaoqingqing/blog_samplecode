﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Drawing
{
    public sealed class SystemFonts
    {
        public static Font DefaultFont { get { return new Font("Arial", 12); } }
    }
}
