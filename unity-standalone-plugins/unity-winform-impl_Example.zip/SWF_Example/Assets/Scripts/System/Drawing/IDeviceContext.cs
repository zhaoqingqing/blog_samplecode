﻿using System;
namespace System.Drawing
{
    public interface IDeviceContext
    {

    }
}
