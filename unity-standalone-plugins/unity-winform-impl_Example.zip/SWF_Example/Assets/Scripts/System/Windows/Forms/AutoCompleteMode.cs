﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Windows.Forms
{
    public enum AutoCompleteMode
    {
        None = 0,
        Suggest = 1,
        Append = 2,
        SuggestAppend = 3,
    }
}
