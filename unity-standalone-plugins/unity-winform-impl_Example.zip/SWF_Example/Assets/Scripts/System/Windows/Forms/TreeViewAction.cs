﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Windows.Forms
{
    public enum TreeViewAction
    {
        Unknown = 0,
        ByKeyboard = 1,
        ByMouse = 2,
        Collapse = 3,
        Expand = 4,
    }
}
