﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Windows.Forms
{
    [Obsolete]
    public class RadioButton : Button
    {
        public bool Checked { get; set; }
    }
}
