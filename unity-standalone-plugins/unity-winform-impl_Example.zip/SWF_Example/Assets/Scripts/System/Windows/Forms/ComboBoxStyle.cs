﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Windows.Forms
{
    public enum ComboBoxStyle
    {
        Simple = 0,
        DropDown = 1,
        DropDownList = 2,
    }
}
