﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

public class TestForm : Form
{
    string hello = "hello world";

    public TestForm()
    {
        Text = "Test Form";

        Button btn = new Button();
        btn.Text = "button";
        btn.Location = new Point(Width - btn.Width - 12, Height - btn.Height - 12);
        Controls.Add(btn);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        e.Graphics.FillRectangle(Color.Green, 64, 64, 32, 24);
        e.Graphics.DrawString(hello, new Font("Arial", 12), Color.Red, 64, 128, 128, 23, ContentAlignment.MiddleCenter);
    }
}
